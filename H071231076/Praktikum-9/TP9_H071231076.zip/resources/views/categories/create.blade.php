<!-- resources/views/categories/create.blade.php -->
@extends('layouts.app')

@section('title', 'Add New Category')

@section('content')
<div class="edit-wrapper">
    <h1>Add New Category</h1>
    <form action="{{ route('categories.store') }}" method="POST">
        @csrf
        <div class="input-box">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="input-box">
            <label for="description">Description</label>
            <textarea name="description" class="form-control" rows="3"></textarea>
        </div>
        <button type="submit" class="btn">Save Category</button>
    </form>
</div>
@endsection
