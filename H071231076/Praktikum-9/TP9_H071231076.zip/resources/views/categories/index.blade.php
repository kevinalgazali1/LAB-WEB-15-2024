<!-- resources/views/categories/index.blade.php -->
@extends('layouts.app')

@section('title', 'Category List')

@section('content')
<div class="category-wrapper">
    <div class="header-container">
        <h2>Category List</h2>
        <a href="{{ route('categories.create') }}" class="btn btn-primary">Add New Category</a>
    </div>
    @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
    @endif
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Description</th>
                <th class="action-column-header">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($categories as $category)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $category->name }}</td>
                    <td>{{ $category->description }}</td>
                    <td class="action-buttons">
                        <a href="{{ route('categories.edit', $category->id) }}" class="btn btn-edit">Edit</a>
                        <form action="{{ route('categories.destroy', $category->id) }}" method="POST" onsubmit="return confirm('Are you sure?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-delete">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
