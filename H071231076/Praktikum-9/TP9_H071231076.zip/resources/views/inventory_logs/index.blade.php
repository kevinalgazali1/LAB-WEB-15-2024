<!-- resources/views/inventory_logs/index.blade.php -->
@extends('layouts.app')

@section('title', 'Inventory Log List')

@section('content')
<div class="admin-wrapper">
    <div class="header-container">
        <h2>Inventory Log List</h2>
        <a href="{{ route('inventory_logs.create') }}" class="btn btn-primary">Add New Inventory Log</a>
    </div>
    @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
    @endif
    <table class="table table-hover table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Product</th>
                <th>Type</th>
                <th>Quantity</th>
                <th>Date</th>
                <th class="action-column-header">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($inventoryLogs as $log)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $log->product->name }}</td>
                    <td>{{ $log->type }}</td>
                    <td>{{ $log->quantity }}</td>
                    <td>{{ $log->date }}</td>
                    <td class="action-column">
                        <form action="{{ route('inventory_logs.destroy', $log->id) }}" method="POST" onsubmit="return confirm('Are you sure?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-delete btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
