<!-- resources/views/inventory_logs/create.blade.php -->
@extends('layouts.app')

@section('title', 'Add New Inventory Log')

@section('content')
<div class="edit-wrapper">
    <h1>Add New Inventory Log</h1>
    <form action="{{ route('inventory_logs.store') }}" method="POST">
        @csrf
        <div class="input-box">
            <label for="product_id">Product</label>
            <select name="product_id" class="form-select" required>
                <option value="" disabled selected>Select Product</option>
                @foreach($products as $product)
                    <option value="{{ $product->id }}">{{ $product->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="input-box">
            <label for="type">Type</label>
            <select name="type" class="form-select" required>
                <option value="restock">Restock</option>
                <option value="sold">Sold</option>
            </select>
        </div>
        <div class="input-box">
            <label for="quantity">Quantity</label>
            <input type="number" name="quantity" class="form-control" required>
        </div>
        <button type="submit" class="btn">Save Inventory Log</button>
    </form>
</div>
@endsection
