<!-- resources/views/products/index.blade.php -->


<?php $__env->startSection('title', 'Product List'); ?>

<?php $__env->startSection('content'); ?>

<div class="admin-wrapper">
    <div class="header-container">
        <h2 class="text-white">Product List</h2>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Add New Product</a>
    </div>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Category</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e(Str::limit($product->description, 50)); ?></td>
                    <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                    <td><?php echo e($product->stock); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td class="action-buttons">
                        <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-edit">Edit</a>
                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-delete" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TP9\resources\views/products/index.blade.php ENDPATH**/ ?>