<!-- resources/views/categories/create.blade.php -->


<?php $__env->startSection('title', 'Add New Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="edit-wrapper">
    <h1>Add New Category</h1>
    <form action="<?php echo e(route('categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="input-box">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="input-box">
            <label for="description">Description</label>
            <textarea name="description" class="form-control" rows="3"></textarea>
        </div>
        <button type="submit" class="btn">Save Category</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TP9\resources\views/categories/create.blade.php ENDPATH**/ ?>