<!-- resources/views/inventory_logs/create.blade.php -->


<?php $__env->startSection('title', 'Add New Inventory Log'); ?>

<?php $__env->startSection('content'); ?>
<div class="edit-wrapper">
    <h1>Add New Inventory Log</h1>
    <form action="<?php echo e(route('inventory_logs.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="input-box">
            <label for="product_id">Product</label>
            <select name="product_id" class="form-select" required>
                <option value="" disabled selected>Select Product</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="input-box">
            <label for="type">Type</label>
            <select name="type" class="form-select" required>
                <option value="restock">Restock</option>
                <option value="sold">Sold</option>
            </select>
        </div>
        <div class="input-box">
            <label for="quantity">Quantity</label>
            <input type="number" name="quantity" class="form-control" required>
        </div>
        <button type="submit" class="btn">Save Inventory Log</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TP9\resources\views/inventory_logs/create.blade.php ENDPATH**/ ?>