<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <header class="fixed-header">
        <div class="navbar-brand">Product Management</div>
        <nav>
            <a href="<?php echo e(route('products.index')); ?>">Product</a>
            <a href="<?php echo e(route('categories.index')); ?>">Category</a>
            <a href="<?php echo e(route('inventory_logs.index')); ?>">Inventory</a>
        </nav>
    </header>
    
    <!-- Main Content -->
    <div class="container">
       
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TP9\resources\views/layouts/app.blade.php ENDPATH**/ ?>