<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\InventoryLogController;

Route::get('/', [ProductController::class, 'index']);

Route::resource('/products', ProductController::class);

Route::resource('/categories', CategoryController::class);

//(hanya CRD)
Route::resource('/inventory_logs', InventoryLogController::class)->only([
    'index', 'create', 'store', 'destroy'
]);
